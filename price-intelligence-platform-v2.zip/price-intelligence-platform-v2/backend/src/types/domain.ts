export type Money = { amount: number; currency: string };

export type PricingContext = {
  organizationId: string;
  productId: string;
  countryCode: string;
  channelId: string;
  paymentProviderId?: string;
  carrierServiceId?: string;
  calculationDate: string;
  quantity: number;
};

export type AppliedRule = {
  ruleId: string;
  ruleType: string;
  version: number;
  priority: number;
  explanation: string;
  effect: Record<string, unknown>;
};

export type CostLine = {
  code: string;
  label: string;
  amount: Money;
  sourceId: string;
  estimated: boolean;
};

export type CalculationResult = {
  allowed: boolean;
  blockedReasons: string[];
  grossPrice: Money;
  netRevenue: Money;
  totalCost: Money;
  margin: Money;
  marginPct: number;
  minimumSustainablePrice: Money;
  maximumSustainableDiscountPct: number;
  suggestedPrice?: Money;
  suggestedDiscountPct?: number;
  costLines: CostLine[];
  appliedRules: AppliedRule[];
  confidenceScore: number;
  warnings: string[];
};
