export interface CatalogAdapter {
  importProducts(): Promise<unknown[]>;
  importInventory(): Promise<unknown[]>;
}

export interface SalesChannelAdapter {
  readCurrentPrice(externalVariantId: string): Promise<number>;
  applyDiscount(externalVariantId: string, discountPct: number): Promise<{ externalOperationId: string }>;
  rollbackDiscount(externalVariantId: string, previousDiscountPct: number): Promise<void>;
}

export interface PaymentAdapter {
  importTransactions(from: string, to: string): Promise<unknown[]>;
}

export interface CarrierAdapter {
  quote(input: Record<string, unknown>): Promise<unknown[]>;
  importRateCard?(fileReference: string): Promise<unknown[]>;
}

export interface CompetitorSourceAdapter {
  collect(productIdentifiers: string[]): Promise<unknown[]>;
}

export interface NotificationAdapter {
  send(message: { recipient: string; subject: string; body: string }): Promise<void>;
}
