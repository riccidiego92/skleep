import { describe, expect, it } from 'vitest';
import { PricingEngine } from './pricing-engine.js';

const context = {
  organizationId: 'org',
  productId: 'product',
  countryCode: 'IT',
  channelId: 'shopify',
  calculationDate: '2026-07-28',
  quantity: 1,
};

describe('PricingEngine', () => {
  it('calcola margine e prezzo minimo', () => {
    const result = new PricingEngine().calculate(context, {
      listPrice: { amount: 100, currency: 'EUR' },
      currentDiscountPct: 0,
      taxRatePct: 22,
      costLines: [{ code: 'product', label: 'Prodotto', amount: { amount: 50, currency: 'EUR' }, sourceId: '1', estimated: false }],
      appliedRules: [{ ruleId: 'r1', ruleType: 'minimum_margin', version: 1, priority: 1, explanation: '', effect: { minimumMarginPct: 25 } }],
    });

    expect(result.allowed).toBe(true);
    expect(result.margin.amount).toBeCloseTo(31.9672, 3);
    expect(result.minimumSustainablePrice.amount).toBeCloseTo(81.3333, 3);
  });

  it('blocca un hard lock', () => {
    const result = new PricingEngine().calculate(context, {
      listPrice: { amount: 100, currency: 'EUR' },
      currentDiscountPct: 0,
      taxRatePct: 22,
      costLines: [],
      appliedRules: [{ ruleId: 'r1', ruleType: 'hard_lock', version: 1, priority: 1000, explanation: '', effect: {} }],
    });

    expect(result.allowed).toBe(false);
  });
});
