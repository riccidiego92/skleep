import type { AppliedRule, CalculationResult, CostLine, Money, PricingContext } from '../types/domain.js';

export type PricingInputs = {
  listPrice: Money;
  currentDiscountPct: number;
  taxRatePct: number;
  costLines: CostLine[];
  appliedRules: AppliedRule[];
};

export class PricingEngine {
  calculate(_context: PricingContext, input: PricingInputs): CalculationResult {
    const blockedReasons = input.appliedRules
      .filter((rule) => rule.ruleType === 'hard_lock')
      .map(() => 'Prodotto bloccato da vincolo commerciale');

    const grossPriceAmount = input.listPrice.amount * (1 - input.currentDiscountPct / 100);
    const netRevenueAmount = grossPriceAmount / (1 + input.taxRatePct / 100);
    const totalCostAmount = input.costLines.reduce((sum, line) => sum + line.amount.amount, 0);
    const marginAmount = netRevenueAmount - totalCostAmount;
    const marginPct = netRevenueAmount > 0 ? (marginAmount / netRevenueAmount) * 100 : -100;

    const minimumMarginRule = input.appliedRules
      .filter((rule) => rule.ruleType === 'minimum_margin')
      .map((rule) => Number(rule.effect.minimumMarginPct ?? 0))
      .reduce((max, value) => Math.max(max, value), 0);

    const targetNetRevenue = minimumMarginRule >= 100
      ? Number.POSITIVE_INFINITY
      : totalCostAmount / (1 - minimumMarginRule / 100);
    const minimumSustainableGross = targetNetRevenue * (1 + input.taxRatePct / 100);
    const maximumDiscountPct = input.listPrice.amount > 0
      ? Math.max(0, (1 - minimumSustainableGross / input.listPrice.amount) * 100)
      : 0;

    return {
      allowed: blockedReasons.length === 0,
      blockedReasons,
      grossPrice: { amount: grossPriceAmount, currency: input.listPrice.currency },
      netRevenue: { amount: netRevenueAmount, currency: input.listPrice.currency },
      totalCost: { amount: totalCostAmount, currency: input.listPrice.currency },
      margin: { amount: marginAmount, currency: input.listPrice.currency },
      marginPct,
      minimumSustainablePrice: { amount: minimumSustainableGross, currency: input.listPrice.currency },
      maximumSustainableDiscountPct: maximumDiscountPct,
      costLines: input.costLines,
      appliedRules: input.appliedRules,
      confidenceScore: input.costLines.some((line) => line.estimated) ? 65 : 95,
      warnings: input.costLines.some((line) => line.estimated) ? ['Sono presenti costi stimati'] : [],
    };
  }
}
