import type { AppliedRule, PricingContext } from '../types/domain.js';

export type RuleRecord = {
  id: string;
  ruleType: string;
  version: number;
  priority: number;
  specificity: number;
  safetyLevel: number;
  scope: Record<string, unknown>;
  conditions: Record<string, unknown>;
  effect: Record<string, unknown>;
};

export interface RuleRepository {
  findCandidates(context: PricingContext): Promise<RuleRecord[]>;
}

export class RuleEngine {
  constructor(private readonly repository: RuleRepository) {}

  async evaluate(context: PricingContext): Promise<AppliedRule[]> {
    const candidates = await this.repository.findCandidates(context);
    return candidates
      .filter((rule) => this.matches(rule, context))
      .sort((a, b) =>
        b.safetyLevel - a.safetyLevel ||
        b.specificity - a.specificity ||
        b.priority - a.priority
      )
      .map((rule) => ({
        ruleId: rule.id,
        ruleType: rule.ruleType,
        version: rule.version,
        priority: rule.priority,
        explanation: `Regola ${rule.ruleType} applicata al contesto corrente`,
        effect: rule.effect,
      }));
  }

  private matches(rule: RuleRecord, context: PricingContext): boolean {
    const scope = rule.scope;
    return (!scope.productId || scope.productId === context.productId)
      && (!scope.countryCode || scope.countryCode === context.countryCode)
      && (!scope.channelId || scope.channelId === context.channelId)
      && (!scope.paymentProviderId || scope.paymentProviderId === context.paymentProviderId)
      && (!scope.carrierServiceId || scope.carrierServiceId === context.carrierServiceId);
  }
}
